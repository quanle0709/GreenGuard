import { getConfig } from '../lib/config.js';
import { makeDemoStatus } from '../lib/demo.js';
import { json } from '../lib/response.js';
import { fetchStatus } from '../lib/thingspeak.js';

export default {
  async fetch(request) {
    if (request.method !== 'GET') return json({ success: false, message: 'Method not allowed.' }, 405, { Allow: 'GET' });
    const config = getConfig();
    try {
      return json(config.demoMode ? makeDemoStatus(config) : await fetchStatus(config));
    } catch (error) {
      return json({ success: false, message: error.message }, 502);
    }
  },
};
