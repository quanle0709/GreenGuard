import { getConfig } from '../lib/config.js';
import { json } from '../lib/response.js';

export default {
  async fetch(request) {
    if (request.method !== 'GET') return json({ success: false, message: 'Method not allowed.' }, 405, { Allow: 'GET' });
    const config = getConfig();
    return json({
      success: true,
      mode: config.demoMode ? 'demo' : 'thingspeak',
      monitoringConfigured: config.demoMode || Boolean(config.channelId),
      controlConfigured: Boolean(config.controlPassword && config.sessionSecret && (config.demoMode || (config.talkBackId && config.talkBackKey))),
      zoneName: config.zoneName,
      timestamp: new Date().toISOString(),
    });
  },
};
