import { getConfig } from '../lib/config.js';
import { makeDemoHistory } from '../lib/demo.js';
import { json } from '../lib/response.js';
import { fetchHistory } from '../lib/thingspeak.js';

export default {
  async fetch(request) {
    if (request.method !== 'GET') return json({ success: false, message: 'Method not allowed.' }, 405, { Allow: 'GET' });
    const config = getConfig();
    try {
      return json(config.demoMode ? makeDemoHistory(config) : await fetchHistory(config));
    } catch (error) {
      return json({ success: false, message: error.message }, 502);
    }
  },
};
