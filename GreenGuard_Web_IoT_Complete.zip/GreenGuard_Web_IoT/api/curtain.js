import { getSessionFromCookie } from '../lib/auth.js';
import { assertControlConfig, getConfig } from '../lib/config.js';
import { json, readJson } from '../lib/response.js';
import { ALLOWED_COMMANDS, enqueueCommand } from '../lib/thingspeak.js';

export default {
  async fetch(request) {
    if (request.method !== 'POST') return json({ success: false, message: 'Method not allowed.' }, 405, { Allow: 'POST' });
    const config = getConfig();
    try {
      assertControlConfig(config);
      if (!getSessionFromCookie(request.headers.get('cookie'), config)) {
        return json({ success: false, message: 'Phiên điều khiển đã hết hạn. Hãy đăng nhập lại.' }, 401);
      }
      const body = await readJson(request);
      const command = String(body.command || '').trim().toUpperCase();
      if (!ALLOWED_COMMANDS.has(command)) return json({ success: false, message: 'Lệnh GreenGuard không hợp lệ.' }, 400);
      if (config.demoMode) {
        return json({ success: true, demo: true, queued: true, command, commandId: `demo-${Date.now()}`, createdAt: new Date().toISOString() });
      }
      return json(await enqueueCommand(config, command));
    } catch (error) {
      return json({ success: false, message: error.message }, 502);
    }
  },
};
