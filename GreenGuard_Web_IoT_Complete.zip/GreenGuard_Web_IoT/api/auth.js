import { assertControlConfig, getConfig } from '../lib/config.js';
import { clearSessionCookie, createSessionToken, getSessionFromCookie, safePasswordEquals, sessionCookie } from '../lib/auth.js';
import { json, readJson } from '../lib/response.js';

export default {
  async fetch(request) {
    const config = getConfig();
    const secure = new URL(request.url).protocol === 'https:';
    if (request.method === 'GET') {
      return json({ success: true, authenticated: getSessionFromCookie(request.headers.get('cookie'), config) });
    }
    if (request.method === 'DELETE') {
      return json({ success: true, authenticated: false }, 200, { 'Set-Cookie': clearSessionCookie(secure) });
    }
    if (request.method !== 'POST') return json({ success: false, message: 'Method not allowed.' }, 405, { Allow: 'GET, POST, DELETE' });
    try {
      assertControlConfig(config);
      const body = await readJson(request);
      if (!safePasswordEquals(body.password, config.controlPassword)) {
        return json({ success: false, message: 'Mật khẩu điều khiển không đúng.' }, 401);
      }
      const token = createSessionToken(config.sessionSecret, config.sessionTtlSeconds);
      return json({ success: true, authenticated: true }, 200, { 'Set-Cookie': sessionCookie(token, config.sessionTtlSeconds, secure) });
    } catch (error) {
      return json({ success: false, message: error.message }, 500);
    }
  },
};
