# GreenGuard Web IoT

A complete rainforest-style monitoring and control website for the GreenGuard plant rain-shield project.

## Included features

- Local rain status at the plant sensor: **Raining / Dry**.
- Curtain status: **Open / Closed**.
- Device connectivity status based on the most recent ThingSpeak update.
- **Automatic / Manual** control modes.
- Password-protected web controls for **Open curtain / Close curtain**.
- ThingSpeak TalkBack command queue.
- Rain statistics: today, last 7 days, cumulative count, and latest rain event.
- Seven-day rain chart and recent event timeline.
- Responsive tropical-rainforest interface.
- ESP32 firmware with rain debounce, dry delay, automatic safety logic, and persistent rain-event counting.
- Demo mode so the website can be tested before real ThingSpeak credentials are entered.

## Project structure

```text
GreenGuard_Web_IoT/
├── index.html                  # Dashboard markup
├── styles.css                 # Rainforest interface
├── app.js                     # Frontend state, charts, controls
├── server.js                  # Zero-dependency local Node server
├── api/                       # Vercel Functions
│   ├── auth.js
│   ├── curtain.js
│   ├── history.js
│   ├── health.js
│   └── status.js
├── lib/                       # Shared backend logic
│   ├── auth.js
│   ├── config.js
│   ├── demo.js
│   ├── response.js
│   └── thingspeak.js
├── firmware/
│   └── GreenGuard_ESP32/
│       ├── GreenGuard_ESP32.ino
│       └── secrets.example.h
├── docs/
│   ├── SETUP_THINGSPEAK.md
│   ├── DEPLOY_VERCEL.md
│   └── HARDWARE_NOTES.md
├── .env.example
├── package.json
└── vercel.json
```

## 1. Run immediately in VS Code

Requirements: Node.js 20 or newer.

```bash
cp .env.example .env
npm run check
npm run dev
```

On Windows PowerShell:

```powershell
Copy-Item .env.example .env
npm run check
npm run dev
```

Open:

```text
http://localhost:3000
```

The default `.env.example` uses `DEMO_MODE=true`. The demo control password is:

```text
change-this-password
```

Change it inside `.env`.

## 2. Connect ThingSpeak

Follow `docs/SETUP_THINGSPEAK.md`, then update `.env`:

```env
DEMO_MODE=false
THINGSPEAK_CHANNEL_ID=1234567
THINGSPEAK_READ_API_KEY=YOUR_READ_KEY
THINGSPEAK_TALKBACK_ID=123456
THINGSPEAK_TALKBACK_KEY=YOUR_TALKBACK_KEY
CONTROL_PASSWORD=YOUR_PRIVATE_CONTROL_PASSWORD
SESSION_SECRET=A_LONG_RANDOM_SECRET
```

Restart the server after changing `.env`.

## 3. Upload firmware

1. Open `firmware/GreenGuard_ESP32/GreenGuard_ESP32.ino` in Arduino IDE or PlatformIO.
2. Copy `secrets.example.h` to `secrets.h`.
3. Fill in Wi-Fi, ThingSpeak, and TalkBack values.
4. Review the pin numbers and servo angles near the top of the `.ino` file.
5. Install these Arduino libraries:
   - ThingSpeak by MathWorks
   - ESP32Servo
6. Upload to the ESP32 and open Serial Monitor at `115200` baud.

## Safety and accuracy limitations

- When no physical limit switches are installed, `curtain_state` is an **inferred software state** after a servo command, not independent proof that the curtain physically reached the requested position.
- For competition-quality evidence, add open/closed limit switches or another position sensor and set `USE_LIMIT_SWITCHES = true` in the firmware.
- The ESP32 keeps automatic rain protection running even when Wi-Fi or ThingSpeak is unavailable.
- Manual **Open** is blocked while rain is detected. Manual **Close** remains allowed.
- Never commit `.env` or `secrets.h` to GitHub.

## Field mapping

| ThingSpeak field | Meaning | Values |
|---|---|---|
| Field 1 | `rain_state` | `0` dry, `1` raining |
| Field 2 | `curtain_state` | `0` open, `1` closed |
| Field 3 | `rain_event_total` | cumulative integer |
| Field 4 | `control_mode` | `0` manual, `1` automatic |
| Field 5 | `command_result` | `0` idle, `1` success, `2` blocked by rain, `3` motor error |

A rain event is counted only when the stable state changes from `0 → 1`; repeated uploads during one rain shower do not inflate the count.
