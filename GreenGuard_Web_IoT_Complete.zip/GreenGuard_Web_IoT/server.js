import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getConfig, assertControlConfig } from './lib/config.js';
import { clearSessionCookie, createSessionToken, getSessionFromCookie, safePasswordEquals, sessionCookie } from './lib/auth.js';
import { makeDemoHistory, makeDemoStatus } from './lib/demo.js';
import { ALLOWED_COMMANDS, enqueueCommand, fetchHistory, fetchStatus } from './lib/thingspeak.js';

const here = path.dirname(fileURLToPath(import.meta.url));
loadEnv(path.join(here, '.env'));
const config = getConfig();

let demoStatus = makeDemoStatus(config);
const demoHistory = makeDemoHistory(config);

const staticFiles = new Map([
  ['/', ['index.html', 'text/html; charset=utf-8']],
  ['/index.html', ['index.html', 'text/html; charset=utf-8']],
  ['/styles.css', ['styles.css', 'text/css; charset=utf-8']],
  ['/app.js', ['app.js', 'text/javascript; charset=utf-8']],
  ['/favicon.svg', ['favicon.svg', 'image/svg+xml']],
  ['/manifest.webmanifest', ['manifest.webmanifest', 'application/manifest+json']],
]);

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (url.pathname.startsWith('/api/')) {
      await handleApi(req, res, url);
      return;
    }
    const asset = staticFiles.get(url.pathname);
    if (!asset) return sendJson(res, 404, { success: false, message: 'Not found.' });
    const [filename, contentType] = asset;
    const content = await fs.promises.readFile(path.join(here, filename));
    res.writeHead(200, { 'Content-Type': contentType, 'Cache-Control': filename === 'index.html' ? 'no-cache' : 'public, max-age=300', 'X-Content-Type-Options': 'nosniff' });
    res.end(content);
  } catch (error) {
    sendJson(res, 500, { success: false, message: error.message });
  }
});

async function handleApi(req, res, url) {
  if (url.pathname === '/api/health' && req.method === 'GET') {
    return sendJson(res, 200, { success: true, mode: config.demoMode ? 'demo' : 'thingspeak', monitoringConfigured: config.demoMode || Boolean(config.channelId), controlConfigured: Boolean(config.controlPassword && config.sessionSecret && (config.demoMode || (config.talkBackId && config.talkBackKey))), zoneName: config.zoneName, timestamp: new Date().toISOString() });
  }
  if (url.pathname === '/api/status' && req.method === 'GET') {
    try { return sendJson(res, 200, config.demoMode ? { ...demoStatus, updatedAt: new Date().toISOString() } : await fetchStatus(config)); }
    catch (error) { return sendJson(res, 502, { success: false, message: error.message }); }
  }
  if (url.pathname === '/api/history' && req.method === 'GET') {
    try { return sendJson(res, 200, config.demoMode ? { ...demoHistory, rainEventTotal: demoStatus.rainEventTotal } : await fetchHistory(config)); }
    catch (error) { return sendJson(res, 502, { success: false, message: error.message }); }
  }
  if (url.pathname === '/api/auth') return handleAuth(req, res);
  if (url.pathname === '/api/curtain') return handleCurtain(req, res);
  return sendJson(res, 404, { success: false, message: 'API route not found.' });
}

async function handleAuth(req, res) {
  if (req.method === 'GET') return sendJson(res, 200, { success: true, authenticated: getSessionFromCookie(req.headers.cookie, config) });
  if (req.method === 'DELETE') return sendJson(res, 200, { success: true, authenticated: false }, { 'Set-Cookie': clearSessionCookie(false) });
  if (req.method !== 'POST') return sendJson(res, 405, { success: false, message: 'Method not allowed.' }, { Allow: 'GET, POST, DELETE' });
  try {
    assertControlConfig(config);
    const body = await readBody(req);
    if (!safePasswordEquals(body.password, config.controlPassword)) return sendJson(res, 401, { success: false, message: 'Mật khẩu điều khiển không đúng.' });
    const token = createSessionToken(config.sessionSecret, config.sessionTtlSeconds);
    return sendJson(res, 200, { success: true, authenticated: true }, { 'Set-Cookie': sessionCookie(token, config.sessionTtlSeconds, false) });
  } catch (error) {
    return sendJson(res, 500, { success: false, message: error.message });
  }
}

async function handleCurtain(req, res) {
  if (req.method !== 'POST') return sendJson(res, 405, { success: false, message: 'Method not allowed.' }, { Allow: 'POST' });
  try {
    assertControlConfig(config);
    if (!getSessionFromCookie(req.headers.cookie, config)) return sendJson(res, 401, { success: false, message: 'Phiên điều khiển đã hết hạn. Hãy đăng nhập lại.' });
    const body = await readBody(req);
    const command = String(body.command || '').trim().toUpperCase();
    if (!ALLOWED_COMMANDS.has(command)) return sendJson(res, 400, { success: false, message: 'Lệnh GreenGuard không hợp lệ.' });
    if (config.demoMode) {
      applyDemoCommand(command);
      return sendJson(res, 200, { success: true, demo: true, queued: true, command, commandId: `demo-${Date.now()}`, createdAt: new Date().toISOString() });
    }
    return sendJson(res, 200, await enqueueCommand(config, command));
  } catch (error) {
    return sendJson(res, 502, { success: false, message: error.message });
  }
}

function applyDemoCommand(command) {
  demoStatus.updatedAt = new Date().toISOString();
  demoStatus.entryId += 1;
  demoStatus.commandResult = 1;
  if (command === 'AUTO_ON') demoStatus.automaticMode = true;
  if (command === 'AUTO_OFF') demoStatus.automaticMode = false;
  if (command === 'CURTAIN_CLOSE') demoStatus.curtainClosed = true;
  if (command === 'CURTAIN_OPEN') {
    if (demoStatus.raining) demoStatus.commandResult = 2;
    else demoStatus.curtainClosed = false;
  }
}

function sendJson(res, status, data, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (chunk) => {
      raw += chunk;
      if (raw.length > 10_000) reject(new Error('Request body too large.'));
    });
    req.on('end', () => {
      try { resolve(raw ? JSON.parse(raw) : {}); }
      catch { reject(new Error('Invalid JSON body.')); }
    });
    req.on('error', reject);
  });
}

function loadEnv(filename) {
  if (!fs.existsSync(filename)) return;
  const lines = fs.readFileSync(filename, 'utf8').split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const index = trimmed.indexOf('=');
    if (index < 1) continue;
    const key = trimmed.slice(0, index).trim();
    let value = trimmed.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (process.env[key] === undefined) process.env[key] = value;
  }
}

server.listen(config.port, () => {
  console.log(`\nGreenGuard dashboard: http://localhost:${config.port}`);
  console.log(`Mode: ${config.demoMode ? 'DEMO' : 'THINGSPEAK'}`);
  console.log('Press Ctrl+C to stop.\n');
});
