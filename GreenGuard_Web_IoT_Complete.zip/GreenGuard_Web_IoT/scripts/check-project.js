import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const required = ['index.html', 'styles.css', 'app.js', 'server.js', '.env.example', 'api/status.js', 'api/history.js', 'api/auth.js', 'api/curtain.js', 'firmware/GreenGuard_ESP32/GreenGuard_ESP32.ino'];
let failed = false;
for (const file of required) {
  const exists = fs.existsSync(path.join(root, file));
  console.log(`${exists ? '✓' : '✗'} ${file}`);
  if (!exists) failed = true;
}

const jsFiles = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.name.endsWith('.js')) jsFiles.push(full);
  }
}
walk(root);
for (const file of jsFiles) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) {
    failed = true;
    console.error(`\nSyntax error: ${path.relative(root, file)}\n${result.stderr}`);
  }
}
console.log(`\nChecked ${jsFiles.length} JavaScript files.`);
if (failed) process.exit(1);
console.log('GreenGuard project check passed.');
