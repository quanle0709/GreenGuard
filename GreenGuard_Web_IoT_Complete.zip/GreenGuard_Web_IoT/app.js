const state = {
  status: null,
  history: [],
  authenticated: false,
  loading: false,
  commandPending: false,
  lastCommand: null,
};

const $ = (selector) => document.querySelector(selector);
const refs = {
  refreshButton: $('#refreshButton'),
  sessionButton: $('#sessionButton'),
  authDialog: $('#authDialog'),
  authForm: $('#authForm'),
  authError: $('#authError'),
  password: $('#controlPassword'),
  loginButton: $('#loginButton'),
  autoButton: $('#autoButton'),
  manualButton: $('#manualButton'),
  openButton: $('#openButton'),
  closeButton: $('#closeButton'),
  commandFeedback: $('#commandFeedback'),
  manualHint: $('#manualHint'),
  rainLayer: $('#rainLayer'),
};

function createRain() {
  const fragment = document.createDocumentFragment();
  for (let i = 0; i < 58; i += 1) {
    const drop = document.createElement('span');
    drop.className = 'raindrop';
    drop.style.left = `${Math.random() * 110}%`;
    drop.style.animationDuration = `${0.75 + Math.random() * 0.8}s`;
    drop.style.animationDelay = `${Math.random() * -2}s`;
    drop.style.opacity = `${0.25 + Math.random() * 0.6}`;
    fragment.append(drop);
  }
  refs.rainLayer.append(fragment);
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  let data = {};
  try { data = await response.json(); } catch { data = {}; }
  if (!response.ok) {
    const error = new Error(data.message || `Request failed (${response.status})`);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

function formatDateTime(value, short = false) {
  if (!value) return 'Chưa có dữ liệu';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Không xác định';
  return new Intl.DateTimeFormat('vi-VN', short
    ? { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }
    : { hour: '2-digit', minute: '2-digit', second: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' }
  ).format(date);
}

function timeAgo(value) {
  if (!value) return 'không xác định';
  const seconds = Math.max(0, Math.round((Date.now() - new Date(value).getTime()) / 1000));
  if (seconds < 60) return `${seconds} giây trước`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} phút trước`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} giờ trước`;
  return `${Math.floor(hours / 24)} ngày trước`;
}

function setText(selector, value) {
  const element = $(selector);
  if (element) element.textContent = value;
}

function updateStatusUI(status) {
  state.status = status;
  const raining = Boolean(status.raining);
  const closed = Boolean(status.curtainClosed);
  const automatic = Boolean(status.automaticMode);
  const online = Boolean(status.systemOnline);

  setText('#zoneName', status.zoneName || 'GreenGuard Plant Zone');
  setText('#rainStatus', raining ? 'Đang mưa' : 'Không mưa');
  setText('#rainDescription', raining ? 'Cảm biến tại cây đang phát hiện nước mưa.' : 'Khu vực cây hiện đang khô ráo.');
  setText('#rainTag', raining ? 'Protection required' : 'Local sensor · dry');
  setText('#heroRainText', raining ? 'Rain detected' : 'Area is dry');

  setText('#curtainStatus', closed ? 'Đang đóng' : 'Đang mở');
  setText('#curtainDescription', closed ? 'Rèm đang che khu vực cây.' : 'Rèm đang mở để cây nhận ánh sáng.');
  setText('#curtainTag', status.curtainVerified ? 'Position verified' : 'Software-inferred state');
  setText('#heroCurtainText', closed ? 'Closed' : 'Open');

  setText('#modeStatus', automatic ? 'Tự động' : 'Thủ công');
  setText('#modeDescription', automatic ? 'ESP32 tự phản ứng theo cảm biến mưa.' : 'Rèm nhận lệnh từ người dùng đã đăng nhập.');

  setText('#systemStatus', online ? 'Online' : 'Mất kết nối');
  setText('#systemDescription', online ? `ESP32 cập nhật ${timeAgo(status.updatedAt)}.` : `Không có cập nhật mới; lần cuối ${timeAgo(status.updatedAt)}.`);
  setText('#entryTag', `Entry ${status.entryId ?? '—'}`);
  setText('#lastUpdated', formatDateTime(status.updatedAt));

  const connection = $('#connectionPill');
  connection.classList.toggle('online', online);
  connection.classList.toggle('offline', !online);
  connection.querySelector('strong').textContent = online ? 'ESP32 online' : 'ESP32 offline';
  $('#syncIndicator').classList.toggle('online', online);

  $('#rainCard').className = `status-card glass-card ${raining ? 'warning' : 'success'}`;
  $('#curtainCard').className = `status-card glass-card ${closed ? 'warning' : 'success'}`;
  $('#systemCard').className = `status-card glass-card ${online ? 'success' : 'danger'}`;

  refs.rainLayer.classList.toggle('active', raining);
  document.body.classList.toggle('curtain-open', !closed);

  refs.autoButton.classList.toggle('active', automatic);
  refs.manualButton.classList.toggle('active', !automatic);

  updateControlAvailability();
  updateCommandResult(status.commandResult);
}

function updateControlAvailability() {
  const automatic = state.status?.automaticMode ?? true;
  const raining = state.status?.raining ?? false;
  const locked = !state.authenticated || state.commandPending;
  refs.autoButton.disabled = locked;
  refs.manualButton.disabled = locked;
  refs.openButton.disabled = locked || automatic || raining;
  refs.closeButton.disabled = locked || automatic;

  if (!state.authenticated) refs.manualHint.textContent = 'Đăng nhập để điều khiển';
  else if (automatic) refs.manualHint.textContent = 'Chuyển sang thủ công để điều khiển';
  else if (raining) refs.manualHint.textContent = 'Mở rèm đang bị chặn vì có mưa';
  else refs.manualHint.textContent = 'Điều khiển thủ công đã sẵn sàng';
}

function updateSessionUI() {
  refs.sessionButton.textContent = state.authenticated ? 'Đăng xuất điều khiển' : 'Đăng nhập điều khiển';
  refs.sessionButton.classList.toggle('authenticated', state.authenticated);
  if (!state.authenticated) {
    showFeedback('Sẵn sàng', 'Đăng nhập để gửi lệnh đến ESP32.', 'info');
  }
  updateControlAvailability();
}

function showFeedback(title, detail, type = 'info') {
  refs.commandFeedback.className = `command-feedback ${type}`;
  refs.commandFeedback.querySelector('strong').textContent = title;
  refs.commandFeedback.querySelector('small').textContent = detail;
  refs.commandFeedback.querySelector('.feedback-icon').textContent = type === 'error' ? '!' : type === 'success' ? '✓' : type === 'pending' ? '…' : 'i';
}

function toast(message, type = 'info') {
  const element = document.createElement('div');
  element.className = `toast ${type}`;
  element.textContent = message;
  $('#toastStack').append(element);
  setTimeout(() => element.remove(), 4200);
}

async function loadStatus({ silent = false } = {}) {
  try {
    const status = await api('/api/status');
    updateStatusUI(status);
    if (!silent) toast('Đã cập nhật trạng thái GreenGuard.', 'success');
    return status;
  } catch (error) {
    setText('#systemStatus', 'Không thể kết nối');
    setText('#systemDescription', error.message);
    $('#connectionPill').className = 'connection-pill offline';
    $('#connectionPill strong').textContent = 'API unavailable';
    $('#syncIndicator').classList.remove('online');
    if (!silent) toast(error.message, 'error');
    throw error;
  }
}

async function loadHistory({ silent = false } = {}) {
  try {
    const data = await api('/api/history');
    state.history = Array.isArray(data.feeds) ? data.feeds : [];
    renderAnalytics(data);
    if (!silent) toast('Đã cập nhật thống kê mưa.', 'success');
  } catch (error) {
    $('#eventTimeline').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
    if (!silent) toast(error.message, 'error');
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
}

function detectEvents(feeds) {
  const events = [];
  let previous = null;
  for (const feed of feeds) {
    const raining = String(feed.field1) === '1';
    const closed = String(feed.field2) === '1';
    const modeAuto = String(feed.field4) === '1';
    const at = feed.created_at;
    if (previous) {
      if (!previous.raining && raining) events.push({ type: 'rain', title: 'Bắt đầu phát hiện mưa', detail: 'Rain state changed 0 → 1', at });
      if (previous.raining && !raining) events.push({ type: 'rain', title: 'Khu vực cây đã khô', detail: 'Rain state changed 1 → 0', at });
      if (!previous.closed && closed) events.push({ type: 'curtain', title: 'Rèm đã đóng', detail: modeAuto ? 'Automatic protection' : 'Manual command', at });
      if (previous.closed && !closed) events.push({ type: 'curtain', title: 'Rèm đã mở', detail: modeAuto ? 'Automatic recovery' : 'Manual command', at });
      if (previous.modeAuto !== modeAuto) events.push({ type: 'mode', title: modeAuto ? 'Bật chế độ tự động' : 'Bật chế độ thủ công', detail: 'Control mode changed', at });
    }
    previous = { raining, closed, modeAuto };
  }
  return events;
}

function localDayKey(date) {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Bangkok', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
  const map = Object.fromEntries(parts.map((p) => [p.type, p.value]));
  return `${map.year}-${map.month}-${map.day}`;
}

function lastSevenDays() {
  const result = [];
  const today = new Date();
  for (let offset = 6; offset >= 0; offset -= 1) {
    const date = new Date(today);
    date.setDate(today.getDate() - offset);
    result.push({ key: localDayKey(date), date });
  }
  return result;
}

function renderAnalytics(data) {
  const events = detectEvents(state.history);
  const rainStarts = events.filter((event) => event.type === 'rain' && event.title.includes('Bắt đầu'));
  const days = lastSevenDays();
  const counts = Object.fromEntries(days.map((day) => [day.key, 0]));
  for (const event of rainStarts) {
    const key = localDayKey(new Date(event.at));
    if (Object.hasOwn(counts, key)) counts[key] += 1;
  }

  const todayKey = days.at(-1).key;
  setText('#todayEvents', counts[todayKey] ?? 0);
  setText('#weekEvents', Object.values(counts).reduce((sum, value) => sum + value, 0));
  setText('#totalEvents', data.rainEventTotal ?? state.status?.rainEventTotal ?? '—');

  const latest = rainStarts.at(-1);
  setText('#latestRain', latest ? formatDateTime(latest.at, true) : 'Chưa ghi nhận');
  setText('#latestRainDetail', latest ? timeAgo(latest.at) : 'Trong dữ liệu đã tải');

  renderChart(days.map((day) => ({ ...day, count: counts[day.key] })));
  renderTimeline(events.slice(-10).reverse());
}

function renderChart(days) {
  const container = $('#rainChart');
  const width = 690;
  const height = 290;
  const left = 34;
  const bottom = 36;
  const top = 22;
  const chartHeight = height - bottom - top;
  const max = Math.max(3, ...days.map((d) => d.count));
  const step = (width - left - 12) / days.length;
  const barWidth = Math.min(48, step * .55);
  const grids = [0, 1, 2, 3].map((index) => {
    const value = Math.round((max / 3) * index);
    const y = top + chartHeight - (value / max) * chartHeight;
    return `<line class="grid-line" x1="${left}" y1="${y}" x2="${width}" y2="${y}"/><text x="2" y="${y + 4}">${value}</text>`;
  }).join('');
  const bars = days.map((day, index) => {
    const x = left + index * step + (step - barWidth) / 2;
    const barHeight = day.count === 0 ? 3 : (day.count / max) * chartHeight;
    const y = top + chartHeight - barHeight;
    const weekday = new Intl.DateTimeFormat('vi-VN', { weekday: 'short' }).format(day.date);
    const date = new Intl.DateTimeFormat('vi-VN', { day: '2-digit', month: '2-digit' }).format(day.date);
    return `<g><title>${date}: ${day.count} lần mưa</title><rect class="bar" x="${x}" y="${y}" width="${barWidth}" height="${barHeight}" rx="8"/><text class="bar-value" text-anchor="middle" x="${x + barWidth / 2}" y="${Math.max(14, y - 8)}">${day.count}</text><text text-anchor="middle" x="${x + barWidth / 2}" y="${height - 18}">${weekday}</text><text text-anchor="middle" x="${x + barWidth / 2}" y="${height - 4}">${date}</text></g>`;
  }).join('');

  container.innerHTML = `<svg class="rain-chart-svg" viewBox="0 0 ${width} ${height}" role="img"><defs><linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#9cf0bf"/><stop offset="100%" stop-color="#2f8560"/></linearGradient></defs>${grids}${bars}</svg>`;
}

function renderTimeline(events) {
  const timeline = $('#eventTimeline');
  setText('#timelineCount', `${events.length} events`);
  if (!events.length) {
    timeline.innerHTML = '<div class="empty-state">Chưa phát hiện chuyển trạng thái trong lịch sử đã tải.</div>';
    return;
  }
  timeline.innerHTML = events.map((event) => `<div class="timeline-event"><span class="timeline-dot ${event.type}"></span><span class="timeline-content"><strong>${escapeHtml(event.title)}</strong><small>${escapeHtml(event.detail)}</small></span><time class="timeline-time">${escapeHtml(formatDateTime(event.at, true))}</time></div>`).join('');
}

async function checkSession() {
  try {
    const result = await api('/api/auth');
    state.authenticated = Boolean(result.authenticated);
  } catch {
    state.authenticated = false;
  }
  updateSessionUI();
}

async function login(password) {
  refs.loginButton.disabled = true;
  refs.loginButton.textContent = 'Đang xác thực…';
  refs.authError.textContent = '';
  try {
    const result = await api('/api/auth', { method: 'POST', body: JSON.stringify({ password }) });
    state.authenticated = Boolean(result.authenticated);
    refs.authDialog.close();
    refs.authForm.reset();
    toast('Đã mở quyền điều khiển GreenGuard.', 'success');
    updateSessionUI();
  } catch (error) {
    refs.authError.textContent = error.message;
  } finally {
    refs.loginButton.disabled = false;
    refs.loginButton.textContent = 'Mở quyền điều khiển';
  }
}

async function logout() {
  try { await api('/api/auth', { method: 'DELETE' }); } catch { /* clear UI anyway */ }
  state.authenticated = false;
  updateSessionUI();
  toast('Đã đăng xuất khỏi bảng điều khiển.');
}

const commandLabels = {
  AUTO_ON: ['Bật tự động', 'ESP32 sẽ tự điều khiển theo cảm biến.'],
  AUTO_OFF: ['Bật thủ công', 'Các nút mở và đóng sẽ được kích hoạt.'],
  CURTAIN_OPEN: ['Mở rèm', 'Đang chờ ESP32 xác nhận trạng thái mở.'],
  CURTAIN_CLOSE: ['Đóng rèm', 'Đang chờ ESP32 xác nhận trạng thái đóng.'],
};

async function sendCommand(command) {
  if (!state.authenticated) {
    refs.authDialog.showModal();
    return;
  }
  state.commandPending = true;
  state.lastCommand = command;
  updateControlAvailability();
  showFeedback(commandLabels[command][0], 'Đang thêm lệnh vào hàng đợi TalkBack…', 'pending');
  try {
    const result = await api('/api/curtain', { method: 'POST', body: JSON.stringify({ command }) });
    showFeedback('Lệnh đã được xếp hàng', commandLabels[command][1], 'pending');
    toast(`TalkBack command #${result.commandId ?? 'queued'}: ${command}`, 'success');
    await waitForConfirmation(command);
  } catch (error) {
    if (error.status === 401) {
      state.authenticated = false;
      updateSessionUI();
      refs.authDialog.showModal();
    }
    showFeedback('Không gửi được lệnh', error.message, 'error');
    toast(error.message, 'error');
  } finally {
    state.commandPending = false;
    updateControlAvailability();
  }
}

function commandConfirmed(command, status) {
  if (command === 'AUTO_ON') return status.automaticMode === true;
  if (command === 'AUTO_OFF') return status.automaticMode === false;
  if (command === 'CURTAIN_OPEN') return status.curtainClosed === false;
  if (command === 'CURTAIN_CLOSE') return status.curtainClosed === true;
  return false;
}

async function waitForConfirmation(command) {
  const deadline = Date.now() + 45000;
  while (Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 4000));
    const status = await loadStatus({ silent: true });
    if (status.commandResult === 2 && command === 'CURTAIN_OPEN') {
      showFeedback('Lệnh bị chặn', 'ESP32 vẫn phát hiện mưa nên không mở rèm.', 'error');
      return;
    }
    if (status.commandResult === 3) {
      showFeedback('Lỗi chuyển động', 'ESP32 báo lỗi motor hoặc công tắc hành trình.', 'error');
      return;
    }
    if (commandConfirmed(command, status)) {
      showFeedback('ESP32 đã xác nhận', commandLabels[command][1], 'success');
      await loadHistory({ silent: true });
      return;
    }
  }
  showFeedback('Chưa nhận được xác nhận', 'Lệnh đã gửi nhưng trạng thái ThingSpeak chưa thay đổi trong 45 giây.', 'error');
}

function updateCommandResult(result) {
  if (!state.lastCommand || state.commandPending) return;
  if (result === 2) showFeedback('Lệnh bị chặn', 'Không thể mở rèm trong khi cảm biến phát hiện mưa.', 'error');
  if (result === 3) showFeedback('Lỗi motor', 'Kiểm tra cơ cấu rèm và cảm biến vị trí.', 'error');
}

async function refreshAll({ silent = false } = {}) {
  if (state.loading) return;
  state.loading = true;
  refs.refreshButton.classList.add('loading');
  refs.refreshButton.disabled = true;
  try {
    await Promise.all([loadStatus({ silent: true }), loadHistory({ silent: true })]);
    if (!silent) toast('Dashboard đã được cập nhật.', 'success');
  } finally {
    state.loading = false;
    refs.refreshButton.classList.remove('loading');
    refs.refreshButton.disabled = false;
  }
}

refs.refreshButton.addEventListener('click', () => refreshAll());
refs.sessionButton.addEventListener('click', () => state.authenticated ? logout() : refs.authDialog.showModal());
refs.authForm.addEventListener('submit', (event) => {
  event.preventDefault();
  login(refs.password.value);
});
for (const button of [refs.autoButton, refs.manualButton, refs.openButton, refs.closeButton]) {
  button.addEventListener('click', () => sendCommand(button.dataset.command));
}

createRain();
await checkSession();
await refreshAll({ silent: true });
setInterval(() => loadStatus({ silent: true }).catch(() => {}), 15000);
setInterval(() => loadHistory({ silent: true }).catch(() => {}), 60000);
