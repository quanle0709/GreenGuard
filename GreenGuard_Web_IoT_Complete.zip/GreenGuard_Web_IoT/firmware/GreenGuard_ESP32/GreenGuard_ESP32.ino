/*
  GreenGuard ESP32 firmware
  ------------------------------------------
  Field 1: rain_state        0 dry / 1 raining
  Field 2: curtain_state     0 open / 1 closed
  Field 3: rain_event_total  cumulative count
  Field 4: control_mode      0 manual / 1 automatic
  Field 5: command_result    0 idle / 1 success / 2 blocked / 3 motor error

  Required libraries:
  - ThingSpeak by MathWorks
  - ESP32Servo

  Copy secrets.example.h to secrets.h before compiling.
*/

#include <WiFi.h>
#include <WiFiClient.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ThingSpeak.h>
#include <ESP32Servo.h>
#include <Preferences.h>
#include "secrets.h"

// ---------- Hardware configuration ----------
constexpr uint8_t RAIN_SENSOR_DIGITAL_PIN = 4;
constexpr bool RAIN_ACTIVE_LOW = true;
constexpr uint8_t SERVO_PIN = 18;
constexpr int SERVO_OPEN_ANGLE = 15;
constexpr int SERVO_CLOSED_ANGLE = 105;
constexpr uint32_t SERVO_MOVE_TIME_MS = 1700;

// Optional limit switches provide genuine physical confirmation.
constexpr bool USE_LIMIT_SWITCHES = false;
constexpr uint8_t OPEN_LIMIT_PIN = 26;
constexpr uint8_t CLOSED_LIMIT_PIN = 27;
constexpr bool LIMIT_ACTIVE_LOW = true;
constexpr uint32_t LIMIT_TIMEOUT_MS = 5000;

// ---------- Timing and filtering ----------
constexpr uint32_t SENSOR_SAMPLE_INTERVAL_MS = 250;
constexpr uint8_t RAIN_CONFIRM_SAMPLES = 5;
constexpr uint32_t DRY_BEFORE_OPEN_MS = 60000;       // wait one dry minute before reopening
constexpr uint32_t TALKBACK_INTERVAL_MS = 5000;
constexpr uint32_t CHANNEL_UPDATE_INTERVAL_MS = 20000; // safe for standard ThingSpeak update intervals
constexpr uint32_t WIFI_RETRY_INTERVAL_MS = 10000;

WiFiClient thingSpeakClient;
Servo curtainServo;
Preferences preferences;

bool automaticMode = true;
bool stableRaining = false;
bool candidateRaining = false;
uint8_t candidateSamples = 0;
bool curtainClosed = false;
bool curtainStateVerified = false;
uint32_t rainEventTotal = 0;
uint8_t commandResult = 0;

uint32_t lastSensorSampleAt = 0;
uint32_t lastTalkBackAt = 0;
uint32_t lastChannelUpdateAt = 0;
uint32_t lastWiFiAttemptAt = 0;
uint32_t dryStartedAt = 0;
bool stateDirty = true;

bool readDigitalActive(uint8_t pin, bool activeLow) {
  const int value = digitalRead(pin);
  return activeLow ? value == LOW : value == HIGH;
}

bool rawRainReading() {
  return readDigitalActive(RAIN_SENSOR_DIGITAL_PIN, RAIN_ACTIVE_LOW);
}

bool limitIsActive(uint8_t pin) {
  return readDigitalActive(pin, LIMIT_ACTIVE_LOW);
}

void connectWiFiNonBlocking() {
  if (WiFi.status() == WL_CONNECTED) return;
  if (millis() - lastWiFiAttemptAt < WIFI_RETRY_INTERVAL_MS) return;
  lastWiFiAttemptAt = millis();
  Serial.printf("Connecting to Wi-Fi: %s\n", WIFI_SSID);
  WiFi.disconnect();
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

void savePersistentState() {
  preferences.putUInt("rainTotal", rainEventTotal);
  preferences.putBool("autoMode", automaticMode);
  preferences.putBool("curtain", curtainClosed);
}

bool waitForLimit(uint8_t pin) {
  const uint32_t startedAt = millis();
  while (millis() - startedAt < LIMIT_TIMEOUT_MS) {
    if (limitIsActive(pin)) return true;
    delay(10);
  }
  return false;
}

bool moveCurtain(bool closeRequested) {
  Serial.println(closeRequested ? "Moving curtain: CLOSE" : "Moving curtain: OPEN");
  curtainServo.write(closeRequested ? SERVO_CLOSED_ANGLE : SERVO_OPEN_ANGLE);

  bool verified = false;
  if (USE_LIMIT_SWITCHES) {
    verified = waitForLimit(closeRequested ? CLOSED_LIMIT_PIN : OPEN_LIMIT_PIN);
  } else {
    delay(SERVO_MOVE_TIME_MS);
    verified = false; // inferred state only; no independent sensor confirmation
  }

  if (USE_LIMIT_SWITCHES && !verified) {
    commandResult = 3;
    curtainStateVerified = false;
    stateDirty = true;
    Serial.println("ERROR: limit switch was not reached.");
    return false;
  }

  curtainClosed = closeRequested;
  curtainStateVerified = verified;
  commandResult = 1;
  stateDirty = true;
  savePersistentState();
  return true;
}

void applyStableRainState(bool newRaining) {
  if (newRaining == stableRaining) return;
  const bool wasRaining = stableRaining;
  stableRaining = newRaining;
  stateDirty = true;

  if (!wasRaining && stableRaining) {
    rainEventTotal += 1;
    dryStartedAt = 0;
    savePersistentState();
    Serial.printf("Rain event #%lu detected.\n", static_cast<unsigned long>(rainEventTotal));
  } else if (wasRaining && !stableRaining) {
    dryStartedAt = millis();
    Serial.println("Rain stopped; dry timer started.");
  }
}

void sampleRainSensor() {
  if (millis() - lastSensorSampleAt < SENSOR_SAMPLE_INTERVAL_MS) return;
  lastSensorSampleAt = millis();
  const bool reading = rawRainReading();

  if (reading != candidateRaining) {
    candidateRaining = reading;
    candidateSamples = 1;
    return;
  }

  if (candidateSamples < RAIN_CONFIRM_SAMPLES) candidateSamples += 1;
  if (candidateSamples >= RAIN_CONFIRM_SAMPLES) applyStableRainState(candidateRaining);
}

void runAutomaticControl() {
  if (!automaticMode) return;

  if (stableRaining && !curtainClosed) {
    moveCurtain(true);
    return;
  }

  if (!stableRaining && curtainClosed) {
    if (dryStartedAt == 0) dryStartedAt = millis();
    if (millis() - dryStartedAt >= DRY_BEFORE_OPEN_MS) moveCurtain(false);
  }
}

void executeCommand(String command) {
  command.trim();
  command.toUpperCase();
  Serial.printf("TalkBack command: %s\n", command.c_str());

  if (command == "AUTO_ON") {
    automaticMode = true;
    commandResult = 1;
    stateDirty = true;
    savePersistentState();
    runAutomaticControl();
    return;
  }

  if (command == "AUTO_OFF") {
    automaticMode = false;
    commandResult = 1;
    stateDirty = true;
    savePersistentState();
    return;
  }

  if (command == "CURTAIN_CLOSE") {
    moveCurtain(true);
    return;
  }

  if (command == "CURTAIN_OPEN") {
    if (stableRaining) {
      commandResult = 2;
      stateDirty = true;
      Serial.println("OPEN blocked: rain is still detected.");
      return;
    }
    moveCurtain(false);
    return;
  }

  Serial.println("Unknown TalkBack command ignored.");
}

void checkTalkBack() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (millis() - lastTalkBackAt < TALKBACK_INTERVAL_MS) return;
  lastTalkBackAt = millis();

  WiFiClientSecure secureClient;
  secureClient.setInsecure(); // Prototype convenience. Pin a CA certificate for production deployments.
  HTTPClient http;
  const String url = "https://api.thingspeak.com/talkbacks/" + String(THINGSPEAK_TALKBACK_ID) + "/commands/execute";

  if (!http.begin(secureClient, url)) {
    Serial.println("TalkBack connection could not be initialized.");
    return;
  }

  http.addHeader("Content-Type", "application/x-www-form-urlencoded");
  const String body = "api_key=" + String(THINGSPEAK_TALKBACK_KEY);
  const int statusCode = http.POST(body);

  if (statusCode == 200) {
    String command = http.getString();
    command.trim();
    if (command.length() > 0) executeCommand(command);
  } else {
    Serial.printf("TalkBack HTTP error: %d\n", statusCode);
  }
  http.end();
}

void updateThingSpeak() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!stateDirty && millis() - lastChannelUpdateAt < CHANNEL_UPDATE_INTERVAL_MS) return;
  if (millis() - lastChannelUpdateAt < CHANNEL_UPDATE_INTERVAL_MS) return;
  lastChannelUpdateAt = millis();

  ThingSpeak.setField(1, stableRaining ? 1 : 0);
  ThingSpeak.setField(2, curtainClosed ? 1 : 0);
  ThingSpeak.setField(3, static_cast<long>(rainEventTotal));
  ThingSpeak.setField(4, automaticMode ? 1 : 0);
  ThingSpeak.setField(5, commandResult);

  const int response = ThingSpeak.writeFields(THINGSPEAK_CHANNEL_ID, THINGSPEAK_WRITE_API_KEY);
  if (response == 200) {
    stateDirty = false;
    Serial.println("ThingSpeak channel updated.");
  } else {
    Serial.printf("ThingSpeak update failed: %d\n", response);
  }
}

void setup() {
  Serial.begin(115200);
  delay(400);

  pinMode(RAIN_SENSOR_DIGITAL_PIN, INPUT_PULLUP);
  if (USE_LIMIT_SWITCHES) {
    pinMode(OPEN_LIMIT_PIN, INPUT_PULLUP);
    pinMode(CLOSED_LIMIT_PIN, INPUT_PULLUP);
  }

  preferences.begin("greenguard", false);
  rainEventTotal = preferences.getUInt("rainTotal", 0);
  automaticMode = preferences.getBool("autoMode", true);
  curtainClosed = preferences.getBool("curtain", false);

  curtainServo.setPeriodHertz(50);
  curtainServo.attach(SERVO_PIN, 500, 2400);
  curtainServo.write(curtainClosed ? SERVO_CLOSED_ANGLE : SERVO_OPEN_ANGLE);

  stableRaining = rawRainReading();
  candidateRaining = stableRaining;
  candidateSamples = RAIN_CONFIRM_SAMPLES;
  if (!stableRaining) dryStartedAt = millis();

  WiFi.mode(WIFI_STA);
  ThingSpeak.begin(thingSpeakClient);
  connectWiFiNonBlocking();

  Serial.println("GreenGuard initialized.");
}

void loop() {
  connectWiFiNonBlocking();
  sampleRainSensor();
  checkTalkBack();
  runAutomaticControl();
  updateThingSpeak();
  delay(5);
}
