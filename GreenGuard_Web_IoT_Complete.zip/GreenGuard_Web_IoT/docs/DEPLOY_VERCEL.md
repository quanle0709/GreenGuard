# Deploy GreenGuard to Vercel

## Before deployment

Use strong values:

```env
DEMO_MODE=false
CONTROL_PASSWORD=your-long-private-password
SESSION_SECRET=at-least-32-random-characters
```

Never upload `.env` to GitHub.

## Deploy

1. Push the project to a private or public GitHub repository. `.env` and `secrets.h` are ignored.
2. Import the repository into Vercel.
3. In **Project Settings → Environment Variables**, add every required value from `.env.example`.
4. Deploy.
5. Visit `/api/health` to check whether monitoring and control are configured.

## Security model

- ThingSpeak TalkBack key remains in the server-side Function.
- The browser receives only an HttpOnly, SameSite session cookie after a correct control password.
- Monitoring endpoints are public by default, but the Read API Key remains hidden in the backend.
- Control commands require a valid signed session.

This password gate is appropriate for a school prototype. For a public production system with multiple users, replace it with a real identity provider and authorization roles.

## Important Vercel demo-mode limitation

Vercel Functions are stateless. Demo commands can return a successful queue response, but simulated state is not guaranteed to persist between function invocations. Use the local Node server for full interactive demo mode, or connect a real ThingSpeak channel before deployment.
