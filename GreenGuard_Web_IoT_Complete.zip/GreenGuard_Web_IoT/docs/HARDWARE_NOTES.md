# GreenGuard hardware notes

## Servo versus DC motor

The included firmware assumes a positional servo. If the physical prototype uses a DC gear motor, replace the servo routine with an H-bridge driver and **always use open and closed limit switches**.

## Physical-state truth

A software variable is not proof that the curtain moved. A servo can stall, disconnect, or slip while code still reports the commanded angle.

Recommended competition-grade configuration:

- Open-position limit switch
- Closed-position limit switch
- Motor timeout
- Mechanical emergency stop or current protection
- Weather-resistant housing for the rain sensor and electronics

Set:

```cpp
constexpr bool USE_LIMIT_SWITCHES = true;
```

and update the two pin constants after wiring the switches.

## Rain-sensor reliability

Cheap rain boards can remain wet after rain stops and may corrode. Calibrate the threshold, mount the plate at an angle, and test false positives from watering or splashes. For better evidence, record:

- Time to detect first drops
- Time to close the curtain
- False-positive rate
- False-negative rate
- Reopening delay after the plate dries

## Fail-safe behavior

The automatic logic runs directly on the ESP32. Wi-Fi and ThingSpeak are secondary. A network failure must not prevent the curtain from closing when local rain is detected.
