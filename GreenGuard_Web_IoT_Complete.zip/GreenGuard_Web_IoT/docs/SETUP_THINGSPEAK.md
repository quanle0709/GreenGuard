# ThingSpeak setup for GreenGuard

## 1. Create the channel

Create one ThingSpeak channel and enable five fields:

1. `rain_state`
2. `curtain_state`
3. `rain_event_total`
4. `control_mode`
5. `command_result`

Record:

- Channel ID
- Read API Key, if the channel is private
- Write API Key for the ESP32

The website backend reads the most recent feed and channel history. The ESP32 writes the five fields.

## 2. Create TalkBack

Go to:

```text
Apps → TalkBack → New TalkBack
```

Record:

- TalkBack ID
- TalkBack API Key

GreenGuard uses these exact command strings:

```text
AUTO_ON
AUTO_OFF
CURTAIN_OPEN
CURTAIN_CLOSE
```

Do not replace them with `0` and `1`, because explicit command names make logs and debugging safer.

## 3. Configure the web project

Copy `.env.example` to `.env`, then set:

```env
DEMO_MODE=false
THINGSPEAK_CHANNEL_ID=YOUR_CHANNEL_ID
THINGSPEAK_READ_API_KEY=YOUR_READ_KEY
THINGSPEAK_TALKBACK_ID=YOUR_TALKBACK_ID
THINGSPEAK_TALKBACK_KEY=YOUR_TALKBACK_KEY
CONTROL_PASSWORD=YOUR_PRIVATE_PASSWORD
SESSION_SECRET=YOUR_LONG_RANDOM_SECRET
```

If the channel is public, `THINGSPEAK_READ_API_KEY` can be left blank. Keeping the channel private is preferable.

## 4. Configure ESP32

Copy:

```text
firmware/GreenGuard_ESP32/secrets.example.h
```

to:

```text
firmware/GreenGuard_ESP32/secrets.h
```

Enter Wi-Fi, Channel Write Key, TalkBack ID, and TalkBack Key.

## 5. Verify the complete loop

1. Upload the firmware.
2. Confirm that the channel receives fields 1–5.
3. Run the website.
4. Log in to the control panel.
5. Select **Manual**.
6. Press **Close curtain**.
7. Confirm in Serial Monitor that ESP32 received `CURTAIN_CLOSE`.
8. Confirm that Field 2 changes to `1`.
9. Press **Open curtain** while the sensor is dry; Field 2 should change to `0`.
10. Wet the rain sensor and attempt to open. ESP32 should reject the command and send Field 5 = `2`.

## Event-counting rule

Do not count every uploaded `rain_state = 1` row as a separate rain event. The ESP32 increments `rain_event_total` only when the stable state changes from dry to raining:

```text
0 → 1
```

This prevents a ten-minute rain shower from being counted dozens of times.
